<?php include 'navbar.php';?>

<div class="main_container" style="height: 700px">
    <div class="notfounddiv">
        <p>The page you are looking for could not be found or is under construction</p>
    </div>
</div>
<?php include 'footer.php';
