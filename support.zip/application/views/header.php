<!DOCTYPE html>
<html>
    <head>
         <meta charset="UTF-8">
        <title>Support Master</title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.datepicker-ui.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/datatables.jqueryui.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/styles.css"> 
          <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/login.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/trial.css"> 
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/main.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/navbar.css">  
         <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.timepicker.min.css">  
          <link rel="icon" type="image/gif" href="<?php echo base_url();?>assets/images/icons/techicon.gif">  
        
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.timepicker.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/main.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/scripts.js"></script>
         <script type="text/javascript" src="<?php echo base_url();?>assets/js/numeral.js"></script>
          <script type="text/javascript" src="<?php echo base_url();?>assets/js/jsPDF.js"></script>
           <script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.js"></script>
            <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
             <script type="text/javascript" src="<?php echo base_url();?>assets/js/dataTables.min.js"></script>
                <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
                 <script type="text/javascript" src="<?php echo base_url();?>assets/js/login.js"></script>
                  <script type="text/javascript" src="<?php echo base_url();?>assets/js/navbar.js"></script>
                    <script type="text/javascript" src="<?php echo base_url();?>assets/js/loadurl.js"></script>
                  
    </head>
    <body>
          <div id="container"> <!-- OPENS THE CONTAINER DIV CLOSED IN THE FOOTER-->
        
   