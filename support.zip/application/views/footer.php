</div> <!-- CLOSES THE CONTAINER DIV OPENED IN THE HEADER -->
<footer class="footerdiv"></footer>
 
</body>
</html>